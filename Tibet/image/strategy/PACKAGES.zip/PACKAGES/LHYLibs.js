/*DOM相关 */
/**
 * 
 * @param Sel   CSS选择器
 * @param isAll 是否匹配多个元素
 */
function getEl(Sel, isAll) {
    if(isAll) {
        return document.querySelectorAll(Sel);
    }
    return document.querySelector(Sel);
}
/**
 * 事件添加（兼容IE浏览器）
 * @param el        事件对象
 * @param type      事件类型
 * @param callBack  事件回调（监听函数）
 */
function addEvent(el, type, callBack) {
    if (el.attachEvent) {
        el.attachEvent('on' + type, callBack);
    } else {
        el.addEventListener(type, callBack, false);
    }
}

/**
 * 移除事件监听（兼容IE浏览器）
 * @param el        事件对象
 * @param type      事件类型
 * @param callBack  事件回调（监听函数）
 */
function removeEvent(el, type, callBack) {
    if (el.detachEvent) {
        el.detachEvent('on' + type, callBack);
    } else {
        el.removeEventListener(type, callBack, false);
    }
}

/**
 * 获取非行内样式
 * @param el     目标元素节点
 * @param attr   对应属性键（key）
 * @returns {*}  对应属性值（value）
 */
function getStyle(el, attr) {
    // 兼容IE
    if (el.currentStyle) {
        return el.currentStyle[attr];
    } else {
        return getComputedStyle(el, null)[attr];
    }
}

/**
 * 扩展对象属性
 * @param oldObj  旧对象
 * @param newObj  新对象
 * @returns {*}   合成属性之后的旧对象
 */
function extend(oldObj, newObj) {
    for (var key in newObj) {
        oldObj[key] = newObj[key];
    }
    return oldObj;
}

/**
 * 回到顶部
 * @param options 配置参数
 * options -> {
 *   el： 触发元素节点
 *   duration: 持续时间
 *   pageScroll：页面滚动回调
 *   compete：回到顶部结束回调
 * }
 */
function scrollToTop(options) {
    let configs = {
        el: "",
        duration: 1000,
        pageScroll: "",
        complete: ""
    };
    options && this.extend(configs, options);
    let offset = null,
        interval = 15,
        duration = configs.duration,
        speed = null,
        timer = null;

    this.addEvent(window, "scroll", () => {
        offset = document.body.scrollTop || document.documentElement.scrollTop;
        configs.pageScroll && configs.pageScroll(offset);
    });

    this.addEvent(configs.el, "click", () => {
        speed = Math.ceil(offset / (duration / interval));
        timer = setInterval(() => {
            if (offset > 0) {
                document.body.scrollTop = document.documentElement.scrollTop = offset - speed;
            } else {
                clearInterval(timer);
                document.body.scrollTop = document.documentElement.scrollTop = 0;
                configs.complete && configs.complete();
            }
        }, interval);
    });
}

/**
 * 将location.search转换为对象类型
 * @param searchStr location.search 值
 * @returns {*}     对象
 */
function convertSearch(searchStr) {
    // 异常处理
    if (!searchStr) {
        return null;
    }else {
        let str = searchStr.slice(1);
        let strArr = str.split('&');
        let obj = {};
        strArr.forEach(item => {
            let arr = item.split('=');
            let key = decodeURI(arr[0]);
            let val = decodeURI(arr[1]);
            obj[key] = val;
        });
        return obj;
    }
}

/**
 * 异常处理（断言）
 * @param  {boolean} expression [判断条件]
 * @param  {string} message     [提示信息]
 * @return {object}             [描述错误的对象]
 */
function assert(expression, message) {
	if (!expression){
		throw {name: 'Assertion Exception', message: message};
	}
}

/**
 * 获取任意数之间的随机数
 * @param  {number} min [最小值]
 * @param  {number} max [最大值]
 * @return {number}     [随机数]
 */
function randomDecimals(min, max) {
    if (min == undefined || max == undefined || isNaN(min) || isNaN(max)) {
        return -1;
    }else {
        return Math.random() * (max - min) + min;
    }
}

/**
 * 获取任意数之间的整数随机数
 * @param  {number} min [最小值]
 * @param  {number} max [最大值]
 * @return {number}     [随机数]
 */
function randomInteger(min, max) {
    if (min == undefined || max == undefined || isNaN(min) || isNaN(max)) {
        return -1;
    }else {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
 }

 /**
 * 获取随机字符
 * @param  {number} length [字符长度]
 * @return {string}        [随机结果]
 */
function randomCharacters(length) {
    var bStr = '';
    bStr += 'QWERTYUIOPASDFGHJKLZXCVBNM';
    bStr += 'qwertyuiopasdfghjklzxcvbnm';
    bStr += '0123456789';
    var rStr = '';
    for (var i = 0; i < length; ++i) {
      var idx = Math.floor(Math.random() * bStr.length);
      rStr += bStr.substring(idx, idx + 1);
    }
    return rStr;
  }

/**
 * XMLHttpRequest for GET
 * @param {string} url       [请求地址]
 * @param {function} success [请求成功回调函数]
 * @param {function} fail    [请求失败回调函数]
 */
function GET(url, success, fail) {
	// 异常处理
	assert(url, "缺乏请求参数！");
	// 创建请求对象
	var request = new XMLHttpRequest();
	// 配置请求
	request.open("GET", url, true);
	// 发送请求
	request.send(null);
	// 监听请求
	request.onreadystatechange = function() {
		if(request.readyState == 4 && request.status == 200) {
			// 请求成功
			// 解析数据
			var response = JSON.parse(request.responseText);
			if(success) { success(response); }
		}else {
			// 请求失败
			if(fail) { fail(request.status); }
		}
	}

}

/**
 * 淡入淡出效果-封装
 * @param element   执行元素
 * @param target    目标值
 * @param duration  持续时间
 * @param completed 回调函数
 */
function fade(element, target, duration, completed) {
    // Exception handling
    if(!element || target == undefined) {
        throw 'Error：Parameter is not complete in function \'changeOpacity\'.';
    }
    // Set the default value
    duration  = duration  ? duration  : 1000;
    // Gets the current opacity
    var curOpa = getCurrentOpacity();
    // Calculating offset
    var offset   = target - curOpa;
    // Set the interval
    var interval = 30;
    // Calculating speed
    var speed    = offset > 0 ? Math.ceil(offset / (duration / interval)) : Math.floor(offset / (duration / interval));
    // Execute transition animations
    var t = setInterval(function () {
        // Update the current opacity
        curOpa = getCurrentOpacity();
        // Determine whether to reach the target
        if((offset > 0 && curOpa < target) || (offset < 0 && curOpa > target)) {
            // Frame by frame change
            element.style.opacity = (curOpa + speed) / 100
        }else { // Has completed the transition animation
            element.style.opacity = target / 100;
            clearInterval(t);
            // Invoke the callback function
            if(completed) {
                completed();
            }
        }
    }, interval);

    function getCurrentOpacity() {
        var curOpa = 0;
        // Compatible with IE browser
        if(element.currentStyle) {
            curOpa = element.currentStyle['opacity'] * 100;
        }else {
            curOpa = getComputedStyle(element, null)['opacity'] * 100;
        }
        return curOpa;
    }
}

/**
 * 获取对象数据类型
 * @param  {anyObject} val [任意值]
 * @return {anyObject}     [返回数据对应数据类型]
 */
function getType(val) {
	// 获取参数返回类型（肯定是对象）和构造函数类型
	var call = Object.prototype.toString.call(val);
	// 下标开始位置
	var startIdx = call.indexOf(" ") + 1;
	// 下标结束为止
	var endIdx = call.lastIndexOf("\]");
	// 将截取出来的字符串转成小写字母并返回
	return call.slice(startIdx, endIdx).toLowerCase();
}

/**
 * 类型判断
 */
{
	(function(){
		var types = ["Null", "Undefined", "Number", "String", "Object", "Function", "RegExp", "Math", "Date", "Array", "boolean"];
		types.map(function(type) {
			Object.prototype["is" + type] = function(val) {
				val = val == undefined ? this : val;
				return getType(val) == type.toLowerCase();
			}
		});
	}());
}


/**
 * 将字符串转为Unicode编码
 * 
 */
{
	Object.prototype.toUnicodeString = function(val) {
		var s = val || this.valueOf() ;
		var numCode = "";
		var resStr = "";
		for (var i = 0; i < s.length; i++) {
			numCode = s.charCodeAt(i);
			numCode = numCode.toString(16);
			numCode = '\\u' + numCode;
			resStr += numCode;
		}
		return resStr;
		
	}
}

// Web缓存相关
/**
 * 本地存储：注册用户
 * @param key      存储用户集合的key
 * @param user     用户信息
 * @param callBack 存储成功回调函数
 */
function registerUser(key, user, callBack) {
    // 定义存储用户信息的集合
    let users = null;
    // 判断本地是否已经存在该用户数据集合
    if(localStorage[key]) {
        // 存在，根据本地用户数据集合来初始化users
        users = JSON.parse(localStorage[key]);
    }else {
        // 不存在，创建一个空数组
        users = [];
    }
    // 添加用户
    users.push(user);
    // 更新本地数据
    localStorage[key] = JSON.stringify(users);
    // 数据存储成功之后调用回调函数
    callBack && callBack();
}


/**
 * 本地存储：判断用户是否存在
 * @param  key      存储用户信息在本地的key
 * @param  gist     判断用户是否存在的依据
 * @param  value    用户输入的值
 * @return isExists 返回查询结果
 */
function determineUserIsExists(key, gist, value) {
    // 记录用户是否存在
    let isExists = false;
    let users    = JSON.parse(localStorage.getItem(key))
    if(users) {
        for(let i = 0; i < users.length; i++) {
            if(users[i][gist] == value) {
                isExists = true;
                break;
            }
        }
    }
    return isExists;
}


/**
 * 判断是否登录成功
 * @param key      存储用户信息在本地的key
 * @param gists    判断依据({账号, 密码})
 * @param response 响应结果(返回状态码和登陆的用户)
 * 0   用户不存在
 * 1   账号或密码密码为空
 * 2   账号或密码错误
 * 200 登录成功
 */

function login(key, gists, response) {
    // 1.默认处理
    response = response || function () {}

    // 2.获取账号密码key
    let acctKey = Object.keys(gists)[0];
    let pswKey  = Object.keys(gists)[1];

    // 3.判断账号密码是否为空
    if(!gists[acctKey] || !gists[pswKey]) { response(1); return; }


    // 4.判断本地数据用户集合是否存在(如果不存在，则直接提示用户不存在)
    if(!localStorage[key]) {
        response(0); return;
    }else {
        // 如果存在，则先判断用户数据集合中是否存在用户，再判断是否登陆成功
        let users = JSON.parse(localStorage[key]);
        let user = null;
        // 判断用户是否存在，如果用户存在则记录该用户
        for(let i = 0; i < users.length; i++) {
            if(users[i][acctKey] == gists[acctKey]) {
                user = users[i];
                // 跳出循环
                break;
            }
        }
        if(user == null) {
            // 用户不存在
            response(0);
        }else if((user[acctKey] == gists[acctKey]) &&  (user[pswKey] == gists[pswKey])){
            response(200, user);
        }else {
            response(2);
        }
    }
}